% Load dataset
fprintf('Loading dataset...\n');
load X; % X should be a 3-D array of the dataset with dimensions 
        % Height x Width x NumberOfImages

patchsize = 12;
retainedDims = 100;
N = 100000;
numbases = 100; % Train 100 first-layer units
numbases2 = 10; % Train 10 second-layer units
gamma = 0.3;    % L1 regularization

% Compute whitening matrices
fprintf('Computing whitening matrices...\n');
compWhitMatrix(patchsize, retainedDims);

% Load computed whitening matrices
load(sprintf('whitM_%d_%d', patchsize^2, retainedDims));

% Get patches from the dataset and whiten them
fprintf('Sampling patches...\n');
x = getBatch(X, patchsize, N);
x = bsxfun(@minus, x, mean(x));
x = whM * x;

% Compute first-layer parameters
fprintf('Computing first-layer parameters...\n');
[B, S] = reg_outer_prod(x, eye(numbases), numbases, numbases, gamma, 10,...
    200, .1, @(B) showcov(B, uwhM));

% Compute second-layer parameters
fprintf('Computing second-layer parameters...\n');
[W, S] = reg_outer_prod2(x, B, numbases, numbases2, gamma, 5, 200, .01, ...
    @(B) showcov(B, uwhM));