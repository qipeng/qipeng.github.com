function y = inferLatentFS(W, B, x, gamma)
% INFERLATENTFS Latent variable inference of the Regularized 
% Outer-product model.
%   Solves the following optimization problem for y:
%       
%     min_y ||X*X' - B*diag(W*y)*B'||^2 + gamma * |y|
%     s.t.  y >= 0
%
%   y = INFERLATENTFS(W, B, x, gamma)
%
%   Written by Peng Qi <pengqi@cs.stanford.edu>
%   Copyright 2013 by Peng Qi and Xiaolin Hu

    beta = 1e-4;
    J = size(W, 2);
    N = size(x, 2);

    y = zeros(J, N);

    BtX = (B' * x) .^ 2;
    BtB = B' * B;

    A = W' * ((BtB).^2) * W + 2*beta*eye(J);
    Q = -W' * (BtX);

    for iter1 = 1:N,
        y(:, iter1) = L1QP_FeatureSign_nn(gamma, A, Q(:, iter1));
    end

end