function [W, S] = reg_outer_prod2(X, B, num_bases, num_bases2, reg_gamma, num_iters, batch_size, epsilon, displayfunc)
% REG_OUTER_PROD2 Learning the first-layer model parameters of the
% regularized outer-product model.
%   [B, S] = REG_OUTER_PROD2(X, B, num_bases, num_bases2, reg_gamma, 
%           num_iters, batch_size, epsilon, displayfunc)
%   X           Column-aligned input data
%   B           First-layer parameters
%   numbases    Number of first-layer bases
%   numbases2   Number of second-layer bases
%   reg_gamma   L1 regularization factor
%   num_iters   Number of epochs through the data
%   batch_size  Mini-batch size
%   epsilon     Learning rate of the second-layer parameters
%   displayfunc Function handle for displaying the first-layer parameters
%               during training (optional)
%
%   Written by Peng Qi <pengqi@cs.stanford.edu>
%   Copyright 2013 by Peng Qi and Xiaolin Hu

[D, N] = size(X);
K = num_bases;
J = num_bases2;
W = 0.1 * rand(K, J);
S = zeros(J, N);

if (exist('batch_size', 'var') && ~isempty(batch_size)),
    timesN = batch_size;
else
    timesN = 1000;
end
batches = N / timesN;

gamma = reg_gamma;

for i=1:num_iters,
    fprintf('\nIteration %d...\n', i);
    
    indperm = randperm(N);

    for batch = 1:batches,
        batch_idx = indperm((batch - 1) * timesN + 1 : batch * timesN);
        xx = X(:, batch_idx);

        BtX = (B' * xx) .^ 2;
        BtB = B' * B;
        
        % Infer latent variables y
        y = inferLatentFS(W, B, xx, gamma);

        % Compute gradient
        wy = W * sparse(y);

        ddw = zeros(K, J);
        for j = 1:timesN,
            if any(y(:,j)),
                ddw = ddw + (BtX(:,j) - diagmult2(wy(:,j), BtB)) * y(:,j)';
            end
        end
        ddw = ddw / timesN;
        ddw = ddw ./ norm(ddw, 'fro') * sqrt(num_bases2);
        
        % Update W
        W = W + epsilon * ddw;
        W(W<0) = 0;
        W = bsxfun(@rdivide, W, sqrt(sum(W.^2)));
        
        if (exist('displayfunc','var') && ~isempty(displayfunc)),
            B_ = [W(:,1) B'];
            B_ = sortrows(B_, -1);
            displayfunc(B_(:,2:end)');
        end
        
        S(:, batch_idx) = y;
        fprintf('.');
      
        if (~mod(batch, 50)),
            fprintf('\n');
            save BW_failsafe B W;
        end
    end
    
end