function compWhitMatrix(w, t)
% COMPWHITMATRIX Compute the PCA whitening and unwhitening
% matrices for a image dataset
%   COMPWHITMATRIX(W) will load the dataset from X.mat and compute
%   whitening/unwhitening matrices for WxW patches, retaininng 99\% of the
%   variance
%
%   COMPWHITMATRIX(W, t) will compute the matrices to retain t-dimensions
%   after whitening.
%
%   The matrices will be named whM and uwhM, respectively, and saved to
%   "whitM_<input_dim>_<output_dim>.mat".
%
%   Adapted from Y. Karklin's code for (Nature'09) by Peng Qi
%   <pengqi@cs.stanford.edu>
%
%   (Nature'09) Y. Karklin and M. S. Lewicki, Emergence of complex cell 
%   properties by learning to generalize in natural scenes.

N = 100000;

load X; % X is Height x Width x Count array of some image dataset
X = double(X);
% make sure each image is mean 0, std 1
for j=1:size(X,3),
  X(:,:,j) = X(:,:,j) - mean(mean(X(:,:,j)));
  X(:,:,j) = X(:,:,j) ./ sqrt(mean(mean(X(:,:,j).^2)));
end;

% sample patches (removing low-contrast patches -- sky -- and subtracting mean of each patch)
nimages = size(X,3);
uh      = size(X,1) - w; 
uw      = size(X,2) - w;

xidx    = ceil(uw*rand(N,1));
yidx    = ceil(uh*rand(N,1));
imagen  = ceil(rand(N,1)*nimages);

x  = zeros(N, w^2);
for i=1:N,
  patch = X(yidx(i):(yidx(i)+w-1),xidx(i):(xidx(i)+w-1),imagen(i));
  mpatch = mean(patch(:));
  while (mean(mean((patch-mpatch).^2)) < 1/10000), % make sure no blank (sky) data slips in
    xidx(i)    = ceil(uw*rand);   
    yidx(i)    = ceil(uh*rand);         
    imagen(i)  = ceil(rand*nimages);
    patch = X(yidx(i):(yidx(i)+w-1),xidx(i):(xidx(i)+w-1),imagen(i));
    mpatch = mean(patch(:));
  end;
  x(i,:) = reshape(patch-mpatch, [1,w*w]);
end;

C = cov(x); [V, D]=svd(C);
if (~exist('t','var'))
    dd = diag(D);
    t = 0;
    ss = 0;
    sum_target = sum(dd);
    while ss < 0.99 * sum_target && t < length(dd),
        t = t + 1;
        ss = sum(dd(1:t));
    end
end

whM =  diag(1./sqrt(diag(D(1:t,1:t))))*V(:,1:t)';
uwhM = V(:,1:t)*diag(sqrt(diag(D(1:t,1:t))));

save(sprintf('whitM_%d_%d.mat',w^2, t), 'whM', 'uwhM');