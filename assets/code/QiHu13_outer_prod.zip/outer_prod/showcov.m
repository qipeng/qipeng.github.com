function showcov(b, V)
% SHOWCOV Display function of image bases
%   SHOWCOV(b,V) displays column-aligned image bases with unwhiten matrix V
%
%   Written by Peng Qi <pengqi@cs.stanford.edu>
%   Copyright 2013 by Peng Qi and Xiaolin Hu

n = size(b,1);
m = size(b,2);
ttt = V(:,1:n)* b;
width = sqrt(size(ttt,1));
height = width;

row = ceil(sqrt(m));
col = row;

buf = ones((height + 1) * row + 1,(width + 1) * col + 1);

for i=1:m,
    y = mod((i-1), col);
    if ~rem(i, col),
        x = i / col - 1;
    else
        x = floor(i / col);
    end
    x = x * (width + 1) + 1;
    y = y * (height + 1) + 1;
    buf(x+1:x+width, y+1:y+height) = reshape(ttt(:,i)./max(abs(ttt(:,i)))/2 + .5,width,height);
end

imagesc(buf); colormap gray; axis image; axis off; drawnow;
end