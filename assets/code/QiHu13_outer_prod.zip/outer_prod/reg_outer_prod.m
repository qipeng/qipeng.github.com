function [B, S] = reg_outer_prod(X, W, num_bases, num_bases2, reg_gamma, num_iters, batch_size, epsilon, displayfunc, oldB)
% REG_OUTER_PROD Learning the first-layer model parameters of the
% regularized outer-product model.
%   [B, S] = REG_OUTER_PROD(X, W, num_bases, num_bases2, reg_gamma, 
%           num_iters, batch_size, epsilon, displayfunc, oldB)
%   X           Column-aligned input data
%   W           Second-layer parameters
%   numbases    Number of first-layer bases
%   numbases2   Number of second-layer bases
%   reg_gamma   L1 regularization factor
%   num_iters   Number of epochs through the data
%   batch_size  Mini-batch size
%   epsilon     Learning rate of the first-layer parameters
%   displayfunc Function handle for displaying the first-layer parameters
%               during training (optional)
%   oldB        Initial value of the first-layer parameters (optional)
%
%   Written by Peng Qi <pengqi@cs.stanford.edu>
%   Copyright 2013 by Peng Qi and Xiaolin Hu

[D, N] = size(X);
K = num_bases;
J = num_bases2;
if (exist('oldB', 'var') && ~isempty(oldB)),
    B = oldB;
else
    B = 0.1 * randn(D, K);
    B = bsxfun(@rdivide, B, sqrt(sum(B.^2)));
end
S = zeros(J, N);

if (exist('batch_size', 'var') && ~isempty(batch_size)),
    timesN = batch_size;
else
    timesN = 1000;
end
batches = N / timesN;

gamma = reg_gamma;

tic;

for i=1:num_iters,
    fprintf('\nIteration %d...\n', i);
    
    indperm = randperm(N);

    for batch = 1:batches,
        iter = (i-1)*batches + batch;
        if iter < 1000,
            % use 200 training examples
            K1 = min(200, num_bases);
            epsb = epsilon;
        else
            % use the full dataset and shrink the learning rate
            K1 = num_bases;
            epsb = epsilon * .3;
        end
        
        
        batch_idx = indperm((batch - 1) * timesN + 1 : batch * timesN);
        xx = X(:, batch_idx);
        
        Bfull = B;
        Wfull = W;
        B_idx = randperm(num_bases);
        B_idx = B_idx(1:K1);
        B = B(:,B_idx);
        W = W(B_idx, :);

        y = inferLatentFS(W, B, xx, gamma);

        wy = W * sparse(y);

        ddb = zeros(D, K1);
        for j = 1:timesN,
            if any(y(:,j)),
                By = bsxfun(@times, B, wy(:,j)');
                ddb = ddb + ((xx(:,j) * xx(:,j)' - By * B') * By); 
            end
        end
        ddb = ddb / timesN; 
        ddb = bsxfun(@rdivide, ddb, max(sqrt(sum(ddb.^2)), 1e-10));
        db = ddb;
        
        B = B + epsb * db;
        B = bsxfun(@rdivide, B, sqrt(sum(B.^2)));
        
        Bfull(:, B_idx) = B;
        B = Bfull;
        W = Wfull;
        
        if (exist('displayfunc','var') && ~isempty(displayfunc)),
            displayfunc(B);
        end
        
        S(:, batch_idx) = y;
        fprintf('.');
        
        if (~mod(batch, 50)),
            fprintf('\n');
        end
    end
    
end