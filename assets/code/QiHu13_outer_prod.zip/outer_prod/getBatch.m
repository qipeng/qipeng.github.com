function X = getBatch(Z, w, N)
% GETBATCH Sample image patches from a image dataset
%   X = GETBATCH(Z,W,N) samples N patches of size WxW from Z,
%   which represents the dataset in a 3-D array with dimensions height,
%   width, and number of images
%
%   Adapted from Y. Karklin's code for (Nature'09) by Peng Qi
%   <pengqi@cs.stanford.edu>
%
%   (Nature'09) Y. Karklin and M. S. Lewicki, Emergence of complex cell 
%   properties by learning to generalize in natural scenes.

Z = double(Z);

nimages = size(Z,3);
uh      = size(Z,1) - w; 
uw      = size(Z,2) - w;

for j=1:size(Z,3),
  Z(:,:,j) = Z(:,:,j) - mean(mean(Z(:,:,j)));
  Z(:,:,j) = Z(:,:,j) ./ sqrt(mean(mean(Z(:,:,j).^2)));
end;

xidx    = randi(uw+1, N, 1);
yidx    = randi(uh+1, N, 1);
imagen  = randi(nimages, N, 1);

X  = zeros(w^2,N);
for i=1:N,
  patch = Z(yidx(i):(yidx(i)+w-1),xidx(i):(xidx(i)+w-1),imagen(i));
  mpatch = mean(patch(:));
  while (mean(mean((patch-mpatch).^2)) < 1/10000), % make sure no blank (sky) data slips in
    xidx(i)    = ceil(uw*rand);   
    yidx(i)    = ceil(uh*rand);         
    imagen(i)  = ceil(rand*nimages);
    patch = Z(yidx(i):(yidx(i)+w-1),xidx(i):(xidx(i)+w-1),imagen(i));
    mpatch = mean(patch(:));
  end;
  X(:,i) = reshape(patch, [w*w,1]);
end;
