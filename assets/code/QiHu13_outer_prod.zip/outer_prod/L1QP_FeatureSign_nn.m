function [x]=L1QP_FeatureSign_nn(lambda,A,b)
% L1QP_FEATURESIGN_NN solves nonnegative quadradic programming 
% using Feature Sign. 
%
%     min  0.5*x'*A*x+b'*x+\lambda*|x|
%     s.t. x >= 0
%
%   [x]=L1QP_FEATURESIGN_NN(lambda,A,b)
%  
%   Adapted from J. Yang's code for (CVPR'09) by Peng Qi
%   <pengqi@cs.stanford.edu>
%
%   (CVPR'09) Jianchao Yang , Kai Yu , Yihong Gong, Thomas Huang. Linear 
%   Spatial Pyramid Matching using Sparse Coding for Image Classification

EPS = 1e-9;
x=zeros(size(A, 1), 1);           %coeff

grad=A*sparse(x)+b;
[ma, mi]=max((-grad).*(x==0));

while true,
  if grad(mi)<-lambda-EPS,
    x(mi)=(-lambda-grad(mi))/A(mi,mi);            
  else
    if all(x==0)
      break;
    end
  end    
  while true,
    a=x~=0;   %active set
    Aa=A(a,a);
    ba=b(a);
    xa=x(a);

    %new b based on unchanged sign
    vect = -lambda*sign(xa)-ba;
    x_new= Aa\vect;
    idx = find(x_new);
    o_new=(vect(idx)/2 + ba(idx))'*x_new(idx) + lambda*sum(abs(x_new(idx)));
    
    %cost based on changing sign
    s=find(xa.*x_new<=0);
    if isempty(s)
      x(a)=x_new;
      loss=o_new;
      break;
    end
    x_min=xa;
    o_min=(Aa*xa/2 + ba)'*xa+lambda*sum(abs(xa));
    d=x_new-xa;
    t=d./xa;
    for zd=s',
      x_s=xa-d/t(zd);
      x_s(zd)=0;  %make sure it's zero
      if (any(x_s<0)), continue; end
%       o_s=L1QP_loss(net,Aa,ba,x_s);
      idx = find(x_s);
      o_s = (Aa(idx, idx)*x_s(idx)/2 + ba(idx))'*x_s(idx)+lambda*sum(abs(x_s(idx)));
      if o_s<o_min,
        x_min=x_s;
        o_min=o_s;
      end
    end
    
    x(a)=x_min;
    loss=o_min;
  end 
    
  grad=A*sparse(x)+b;
  
  [ma mi]=max((-grad).*(x==0));
  if ma <= lambda+EPS,
    break;
  end  
end

if (any(x < 0)), error('Negative coefficient from NNFS'); end