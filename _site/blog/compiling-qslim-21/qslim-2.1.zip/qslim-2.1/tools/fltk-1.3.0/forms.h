// this file allows some forms programs to be compiled with no change.
// put it in your include path.
#include <FL/forms.H>
